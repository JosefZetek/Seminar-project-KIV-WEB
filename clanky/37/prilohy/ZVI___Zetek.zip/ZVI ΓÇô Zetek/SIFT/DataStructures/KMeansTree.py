import numpy as np
import random

class KMeansTreeNode:
    def __init__(self, feature_vectors, depth=0, max_depth=10, branch_factor=8, cluster_iterations=10):
        self.children = []
        self.is_leaf = False
        
        if not feature_vectors:
            self.is_leaf = True
            self.feature_vectors = []
            self.center = None
            return

        self.center = self.__find_mean(feature_vectors) # self.center is a NumPy array
        self.feature_vectors = None # Set in leaf nodes

        if len(feature_vectors) <= branch_factor or depth >= max_depth:
            self.is_leaf = True
            self.feature_vectors = feature_vectors # Stores list of original feature vector objects
            return

        num_initial_centers = min(branch_factor, len(feature_vectors))
        initial_center_objects = random.sample(list(feature_vectors), k=num_initial_centers)
        k_means_centers = np.array([fv.values for fv in initial_center_objects]) # NumPy array of center values

        final_clusters_of_objects = [[] for _ in range(num_initial_centers)]

        for iteration in range(cluster_iterations):
            clusters_of_objects = [[] for _ in range(num_initial_centers)]

            for fv_object in feature_vectors:
                dists = np.linalg.norm(k_means_centers - fv_object.values, axis=1)
                cluster_idx = np.argmin(dists)
                clusters_of_objects[cluster_idx].append(fv_object)

            new_k_means_centers_list = []
            any_cluster_updated = False
            for i, cluster_obj_list in enumerate(clusters_of_objects):
                if cluster_obj_list:
                    cluster_values = np.array([obj.values for obj in cluster_obj_list])
                    new_center_val = np.mean(cluster_values, axis=0)
                    new_k_means_centers_list.append(new_center_val)
                    if not np.allclose(k_means_centers[i] if i < len(k_means_centers) else new_center_val , new_center_val): # check if i is valid index for k_means_centers
                        any_cluster_updated = True
                else:
                    if i < len(k_means_centers):
                         new_k_means_centers_list.append(k_means_centers[i])
                    else:
                         new_k_means_centers_list.append(random.choice(feature_vectors).values)


            if not new_k_means_centers_list:
                 self.is_leaf = True
                 self.feature_vectors = feature_vectors
                 return

            new_k_means_centers = np.array(new_k_means_centers_list)

            if len(new_k_means_centers) == len(k_means_centers) and np.allclose(k_means_centers, new_k_means_centers) and iteration > 0 :
                final_clusters_of_objects = clusters_of_objects
                break
            
            k_means_centers = new_k_means_centers
            final_clusters_of_objects = clusters_of_objects

            if not any_cluster_updated and iteration > 0:
                break


        for cluster_obj_list in final_clusters_of_objects:
            if len(cluster_obj_list) > 0:
                child = KMeansTreeNode(cluster_obj_list, depth + 1, max_depth, branch_factor, cluster_iterations)
                self.children.append(child)
        
        if not self.children:
            self.is_leaf = True
            self.feature_vectors = feature_vectors


    def find_nearest_candidates(self, feature_vector_obj, number_of_candidates=2):
        nearest_candidate_objects = []
        self.__collect_nearest(nearest_candidate_objects, feature_vector_obj)

        if not nearest_candidate_objects:
            return []

        nearest_candidate_objects.sort(key=lambda obj: np.linalg.norm(obj.values - feature_vector_obj.values))
        
        return nearest_candidate_objects[:min(len(nearest_candidate_objects), number_of_candidates)]

    def __collect_nearest(self, nearest_candidate_objects, feature_vector_obj):
        if self.is_leaf:
            if self.feature_vectors:
                nearest_candidate_objects.extend(self.feature_vectors)
            return

        sorted_children = sorted(
            [child for child in self.children if child.center is not None], 
            key=lambda child: np.linalg.norm(child.center - feature_vector_obj.values)
        )

        for child in sorted_children[:2]:
            child.__collect_nearest(nearest_candidate_objects, feature_vector_obj)

    def __find_mean(self, feature_vector_objects):
        if not feature_vector_objects:
            return None

        sum_of_values = np.sum([fv.values for fv in feature_vector_objects], axis=0)
        return sum_of_values / len(feature_vector_objects)