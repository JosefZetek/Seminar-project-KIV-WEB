class Match:

    def __init__(self, feature_vector1, feature_vector2):
        """
        Constructor initializing the two feature vectors to be matched.
        :param feature_vector1: First feature vector.
        :param feature_vector2: Second feature vector.
        """
        self.feature_vector1 = feature_vector1
        self.feature_vector2 = feature_vector2
        self.distance = self.feature_vector1.distance_to(self.feature_vector2)