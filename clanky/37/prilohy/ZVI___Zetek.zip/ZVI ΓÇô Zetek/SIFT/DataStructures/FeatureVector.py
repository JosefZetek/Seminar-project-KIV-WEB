class FeatureVector:

    def __init__(self, point, values):
        """
        Constructor initializing the point and values of the feature vector.
        :param point: Instance of class Point representing the location of the feature in the image.
        :param values: Descriptor values of the feature vector.
        """
        self.point = point
        self.values = values

    def distance_to(self, other_fv):
        """
        Method calculating the distance between two descriptors.
        :param other_fv: Descriptor to compare with.
        :return: Returns the distance between the two descriptors.
        """

        if not isinstance(other_fv, FeatureVector):
            raise TypeError("The other object must be an instance of FeatureVector")

        if len(self.values) != len(other_fv.values):
            return float('inf')

        return sum((a - b) ** 2 for a, b in zip(self.values, other_fv.values)) ** 0.5

    def __str__(self):
        """
        Method converting the descriptor to a string representation.
        :return: Returns string representation of the descriptor.
        """
        return f"FeatureVector({self.point}, {self.values})"