class Point:
    """
    A class representing a point in 2D space.
    """

    def __init__(self, x: float, y: float):
        """
        Constructor initializing x, y and z coordinates of the point.
        :param x: X coordinate of the point.
        :param y: Y coordinate of the point.
        """
        self.x = x
        self.y = y

    def __str__(self):
        """
        Method converting the point to a string representation.
        :return: Returns string representation of the point.
        """
        return f"Point({self.x}, {self.y})"
