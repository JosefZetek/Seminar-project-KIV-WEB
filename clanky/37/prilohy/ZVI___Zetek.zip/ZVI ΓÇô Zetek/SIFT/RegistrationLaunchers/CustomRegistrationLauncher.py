from Modules.FeatureComputer import FeatureComputer
from Modules.Matcher import Matcher
from Modules.MatcherFLANN import MatcherFLANN
from Modules.Preprocesor import Preprocesor
from Modules.Sampler import Sampler
from Modules.TransformationComputer import TransformationComputer

import random

class CustomRegistrationLauncher:

    def __init__(self):
        self.matcher = Matcher()
        self.transformation_computer = TransformationComputer()

    def get_matches(self, number_of_scales, contrast_threshold, edge_threshold, number_of_bins, image_path1, image_path2):
        preprocesor = Preprocesor(number_of_scales)
        sampler = Sampler(contrast_threshold, edge_threshold)
        feature_computer = FeatureComputer(number_of_bins)

        image1 = preprocesor.load_image_grayscale(image_path1)
        image2 = preprocesor.load_image_grayscale(image_path2)

        blurred_images1 = preprocesor.get_blurred_images(image1)
        blurred_images2 = preprocesor.get_blurred_images(image2)

        image1_keypoints = sampler.get_keypoints(blurred_images1)
        image2_keypoints = sampler.get_keypoints(blurred_images2)

        image1_feature_vectors = feature_computer.get_feature_vector(blurred_images1, image1_keypoints)
        image2_feature_vectors = feature_computer.get_feature_vector(blurred_images2, image2_keypoints)

        matches = self.matcher.match(image1_feature_vectors, image2_feature_vectors)
        random.shuffle(matches)

        self.transformation_computer.get_points_array(matches)
        return self.transformation_computer.get_points_array(matches)

    def get_transformation(self, src, dst):
        H = self.transformation_computer.compute_transformation_points(src, dst)
        return H