import cv2
import numpy as np
import matplotlib.pyplot as plt

class OpenCVRegistrationLauncher:

    def __init__(self):
        pass

    def get_matches(self, image_path1, image_path2):

        img1 = cv2.imread(image_path1)
        img2 = cv2.imread(image_path2)

        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

        sift = cv2.SIFT_create()
        kp1, desc1 = sift.detectAndCompute(gray1, None)
        kp2, desc2 = sift.detectAndCompute(gray2, None)

        # Match with FLANN
        index_params = dict(algorithm=1, trees=5)
        search_params = dict(checks=50)
        flann = cv2.FlannBasedMatcher(index_params, search_params)
        matches = flann.knnMatch(desc1, desc2, k=2)

        # Lowe's ratio test
        good_matches = [m for m, n in matches if m.distance < 0.75 * n.distance]

        if len(good_matches) < 4:
            raise ValueError("Not enough good matches to compute homography.")

        # Get points as (x, y)
        src_pts = np.float32([kp1[m.queryIdx].pt for m in good_matches])
        dst_pts = np.float32([kp2[m.trainIdx].pt for m in good_matches])

        return src_pts, dst_pts  # shape: (N, 2)

    def get_transformation(self, src_pts, dst_pts):
       H, _ = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
       return H