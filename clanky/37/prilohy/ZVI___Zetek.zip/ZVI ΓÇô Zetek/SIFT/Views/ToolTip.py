import tkinter as tk

class ToolTip:
    def __init__(self, widget, text):
        """
        Create a tooltip for a given widget.
        :param widget: Widget to attach the tooltip to
        :param text: Text to display in the tooltip
        """

        self.widget = widget
        self.text = text
        self.tip_window = None
        self.widget.bind("<Enter>", self.show_tip)
        self.widget.bind("<Leave>", self.hide_tip)

    def show_tip(self, event=None):
        """
        Display the tooltip at the current mouse position.
        :param event: Event object (optional)
        """

        if self.tip_window or not self.text:
            return
        x, y, _, _ = self.widget.bbox("insert") if self.widget.bbox("insert") else (0, 0, 0, 0)
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        self.tip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.geometry(f"+{x}+{y}")
        label = tk.Label(
            tw, text=self.text, justify='left',
            background="#ffffe0", relief='solid', borderwidth=1,
            font=("Arial", 9)
        )
        label.pack(ipadx=1)

    def hide_tip(self, event=None):
        """
        Hide the tooltip.
        :param event: Event object (optional)
        """

        if self.tip_window:
            self.tip_window.destroy()
            self.tip_window = None