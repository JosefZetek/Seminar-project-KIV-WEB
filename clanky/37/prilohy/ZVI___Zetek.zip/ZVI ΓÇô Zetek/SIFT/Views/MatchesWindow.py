import tkinter as tk
import cv2
from PIL import Image, ImageTk
from Modules.Presenter import Presenter

class MatchesWindow:
    def __init__(self, master, registration_launcher):
        """
        Initialize the MatchesWindow.
        :param master: Master window (usually the main application window).
        :param registration_launcher: An instance of the registration launcher to handle image registration.
        """

        self.window = tk.Toplevel(master)
        self.window.title("Matches")
        self.window.geometry("800x600")
        self.window.withdraw()
        self.registration_launcher = registration_launcher

    def create_widgets(self, image1, image2, src, dst):
        """
        Method to create the widgets for the MatchesWindow.
        :param image1: First image to be displayed
        :param image2: Second image to be displayed
        :param src: Source points from the first image
        :param dst: Destination points from the second image
        """

        if image1 is None:
            print("Image is None")
            return

        # Save inputs so we can reuse them when the slider changes
        self.image1 = image1
        self.image2 = image2
        self.src = src
        self.dst = dst

        # Initial draw
        combined = Presenter.draw_matches(image1, image2, src, dst, limit=10)
        pil_img = Image.fromarray(combined)
        self.tk_image = ImageTk.PhotoImage(pil_img)

        self.image_label = tk.Label(self.window, image=self.tk_image)
        self.image_label.pack()

        # Add slider with command callback
        self.slider = tk.Scale(self.window, from_=1, to=100, orient=tk.HORIZONTAL, command=self.on_slider_change)
        self.slider.set(10)  # initial value
        self.slider.pack(fill=tk.X, padx=10, pady=10)

        self.quit_button = tk.Button(self.window, text="Show result", command=self.show_result)
        self.quit_button.pack(pady=10)

        self.window.deiconify()

    def on_slider_change(self, value):
        """
        Method to handle slider changes.
        :param value: Value from the slider
        """

        limit = int(value)
        updated_image = Presenter.draw_matches(self.image1, self.image2, self.src, self.dst, limit=limit)

        pil_img = Image.fromarray(updated_image)
        self.tk_image = ImageTk.PhotoImage(pil_img)  # Must keep a reference!
        self.image_label.configure(image=self.tk_image)

    def show_result(self):
        """
        Method to show the result of the image registration.
        """

        H = self.registration_launcher.get_transformation(self.src[:((len(self.src) - 1) * self.slider.get()// 100)], self.dst[:((len(self.dst) - 1) * self.slider.get()// 100)])
        stitched_image = Presenter.stitch_images(self.image1, self.image2, H)
        Presenter.show_image_color(stitched_image, "Stitched Image")

