from Modules.Preprocesor import Preprocesor
from Views.MatchesWindow import MatchesWindow
from Views.ToolTip import ToolTip

import tkinter as tk
import ctypes
import os
from tkinter import ttk, filedialog, Entry



class ParameterForm:
    def __init__(self, custom_registration_launcher, opencv_registration_launcher):
        """
        Initializes the parameter form for SIFT image registration.
        :param custom_registration_launcher: Custom implementation of SIFT registration.
        :param opencv_registration_launcher: OpenCV implementation of SIFT registration.
        """
        self.window = self.__init_window()

        self.entries = {}
        self.image_path1 = None
        self.image_path2 = None

        self.method_var = tk.StringVar(value="Custom implementation")

        self.__create_header()
        self.__create_form()
        self.__create_method_dropdown()
        self.__create_image_selection()
        self.__create_run_button()
        self.__enable_high_dpi_scaling()

        self.custom_registration_launcher = custom_registration_launcher
        self.opencv_registration_launcher = opencv_registration_launcher

    def show(self):
        """
        Displays the main window.
        :return:
        """
        self.window.mainloop()

    def __enable_high_dpi_scaling(self):
        """
        Method enables high DPI scaling on Windows to ensure the application looks good on high-resolution displays.
        """
        if os.name != 'nt':
            return

        if hasattr(ctypes.windll.shcore, "SetProcessDpiAwareness"):
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(1)
            except Exception as e:
                print(f"Error enabling high DPI scaling: {e}")

    def __init_window(self):
        """
        Initializes the main window for the SIFT parameter configuration.
        :return: Returns the initialized window object.
        """
        window = tk.Tk()
        window.title("SIFT Parameter Configuration")
        window.geometry("460x450")
        window.resizable(False, False)
        window.option_add("*Font", "Arial 10")
        return window

    def __create_header(self):
        """
        Creates the header for the parameter form.
        """

        header = tk.Label(
            self.window,
            text="KIV / SIFT Parameter Form",
            font=("Arial", 14, "bold"),
            anchor="center"
        )
        header.pack(pady=(15, 10))

        header_description = tk.Label(
            self.window,
            text="Please enter the parameters for the SIFT algorithm or leave them empty to use default values.",
            font=("Arial", 10),
            anchor="center",
            wraplength=400
        )
        header_description.pack(pady=(0, 15))

    def __create_form(self):
        """
        Creates the form for entering SIFT parameters.
        """

        parameters = [
            ("Number of scales", "Number of intervals per octave (minimum 4)."),
            ("Contrast threshold", "Threshold to filter out low-contrast keypoints (e.g., 0.04)."),
            ("Edge threshold", "Eliminates unstable keypoints along edges (e.g., 10)."),
            ("Number of bins", "Number of bins in the orientation histogram (e.g., 36).")
        ]

        self.form_frame = ttk.Frame(self.window, padding="10")
        self.form_frame.columnconfigure(1, weight=1)
        self.form_frame.pack(fill=tk.BOTH, expand=False)

        for i, (label_text, tooltip_text) in enumerate(parameters):
            ttk.Label(self.form_frame, text=label_text + ":").grid(row=i, column=0, sticky="w", padx=5, pady=6)
            entry = ttk.Entry(self.form_frame, width=25)
            entry.grid(row=i, column=1, padx=(5, 15), pady=6, sticky="ew")
            ToolTip(entry, tooltip_text)
            self.entries[label_text] = entry

    def __create_method_dropdown(self):
        """
        Creates a dropdown menu for selecting the implementation method (Custom or OpenCV).
        """

        dropdown_frame = ttk.Frame(self.window, padding="10")
        dropdown_frame.columnconfigure(1, weight=1)
        dropdown_frame.pack(fill=tk.X)

        ttk.Label(dropdown_frame, text="Implementation method:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        method_dropdown = ttk.Combobox(
            dropdown_frame,
            textvariable=self.method_var,
            values=["Custom implementation", "OpenCV"],
            state="readonly"
        )
        method_dropdown.grid(row=0, column=1, padx=(5, 15), pady=5, sticky="ew")
        ToolTip(method_dropdown, "Choose between custom or OpenCV's implementation of SIFT.")

    def __create_image_selection(self):
        """
        Creates the image selection buttons and labels for displaying selected images.
        """

        image_frame = ttk.Frame(self.window, padding="10")
        image_frame.columnconfigure((0, 1), weight=1)
        image_frame.pack(fill=tk.X)

        button1 = ttk.Button(image_frame, text="Select Image 1", command=lambda: self.__select_image(1))
        button1.grid(row=0, column=0, padx=(5, 10), pady=5, sticky="ew")

        button2 = ttk.Button(image_frame, text="Select Image 2", command=lambda: self.__select_image(2))
        button2.grid(row=0, column=1, padx=(10, 5), pady=5, sticky="ew")

        # File name or tick display labels
        self.image_label1 = ttk.Label(image_frame, text="", foreground="green", wraplength=200)
        self.image_label1.grid(row=1, column=0, pady=(0, 5))

        self.image_label2 = ttk.Label(image_frame, text="", foreground="green", wraplength=200)
        self.image_label2.grid(row=1, column=1, pady=(0, 5))

    def __create_run_button(self):
        """
        Creates the "Run" button to execute the registration process.
        """
        button_frame = ttk.Frame(self.window, padding=(10, 0, 10, 10))
        button_frame.pack(fill=tk.X, side=tk.BOTTOM)

        button = ttk.Button(button_frame, text="Run", command=self.__run_registration)
        button.pack(side=tk.RIGHT)

    def __select_image(self, image_number):
        """
        Method to select an image file using a file dialog.
        :param image_number: Image number (1 or 2) to identify which image is being selected.
        """

        file_path = filedialog.askopenfilename(
            title=f"Select Image {image_number}",
            filetypes=[("Image Files", "*.png *.jpg *.jpeg *.bmp")]
        )
        if file_path:
            filename = file_path.split("/")[-1]  # Show just the file name
            if image_number == 1:
                self.image_path1 = file_path
                self.image_label1.config(text=f"✅ {filename}")
            elif image_number == 2:
                self.image_path2 = file_path
                self.image_label2.config(text=f"✅ {filename}")

    def __run_registration(self):
        """
        Method to run registration based on the selected parameters and images.
        """

        scales = self.__get_value("Number of scales")
        contrast = self.__get_value("Contrast threshold")
        edge = self.__get_value("Edge threshold")
        bins = self.__get_value("Number of bins")
        method = self.method_var.get()

        # Validate inputs
        scales = min(self.__validate_input("Number of scales", scales, 5, "int"), 5)
        contrast = self.__validate_input("Contrast threshold", contrast, 0.04, "float")
        edge = self.__validate_input("Edge threshold", edge, 10, "int")
        bins = self.__validate_input("Number of bins", bins, 36, "int")

        if not all([scales, contrast, edge, bins]):
            return

        if not self.image_path1 or not self.image_path2:
            self.__show_invalid_input("Image selection", False)
            return

        if method == "Custom implementation":
            src, dst = self.custom_registration_launcher.get_matches(scales, contrast, edge, bins, self.image_path1, self.image_path2)
            im1 = Preprocesor.load_image_color(self.image_path1)
            im2 = Preprocesor.load_image_color(self.image_path2)

            self.matches_window = MatchesWindow(self.window, self.custom_registration_launcher)
            self.matches_window.create_widgets(im1, im2, src, dst)

        elif method == "OpenCV":
            src, dst = self.opencv_registration_launcher.get_matches(self.image_path1, self.image_path2)
            im1 = Preprocesor.load_image_color(self.image_path1)
            im2 = Preprocesor.load_image_color(self.image_path2)

            self.matches_window = MatchesWindow(self.window, self.opencv_registration_launcher)
            self.matches_window.create_widgets(im1, im2, src, dst)


    def __get_value(self, attribute_name):
        """
        Method to get the value of an entry field.
        :param attribute_name: Name of the attribute to get the value for.
        :return: Returns the value of the entry field or None if not set.
        """

        value = self.entries.get(attribute_name)
        return value.get() if value else None

    def __show_invalid_input(self, attribute_name, has_default_value=False):
        """
        Method to show an alert for invalid input.
        :param attribute_name: Name of the attribute with invalid input.
        :param has_default_value: Default value flag to indicate if the input can be empty.
        """

        alert = tk.Toplevel(self.window)
        alert.title("Invalid Input")
        alert.geometry("300x100")
        alert_label = tk.Label(alert, text=f"Invalid input for {attribute_name}. Please enter a valid value{' or leave it empty' if has_default_value else ''}.", wraplength=250)
        alert_label.pack(pady=10)
        alert_button = ttk.Button(alert, text="OK", command=alert.destroy)
        alert_button.pack(pady=5)

    def __validate_input(self, attribute_name, value, default_value, type_):
        """
        Method to validate the input value.
        :param attribute_name: Name of the attribute to validate.
        :param value: Value to validate.
        :param default_value: Default value to return if the input is empty.
        :param type_:  Type of the value to validate (int or float).
        :return: Returns the validated value or None if invalid.
        """

        if not value or value == "":
            return default_value

        try:
            if type_ == "int":
                return int(value)
            elif type_ == "float":
                return float(value)
            else:
                self.__show_invalid_input(attribute_name, True)
                return None
        except ValueError:
            self.__show_invalid_input(attribute_name)
            return None
