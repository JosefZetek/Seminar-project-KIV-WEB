from RegistrationLaunchers.CustomRegistrationLauncher import CustomRegistrationLauncher
from RegistrationLaunchers.OpenCVRegistrationLauncher import OpenCVRegistrationLauncher
from Views.MainView import ParameterForm

if __name__ == '__main__':
    custom_registration_launcher = CustomRegistrationLauncher()
    opencv_registration_launcher = OpenCVRegistrationLauncher()

    app = ParameterForm(custom_registration_launcher, opencv_registration_launcher)
    app.show()
