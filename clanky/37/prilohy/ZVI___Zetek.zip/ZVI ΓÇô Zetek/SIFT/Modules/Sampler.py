import numpy as np

class Sampler:

    def __init__(self, contrast_threshold=0.03, edge_threshold=10):
        """
        Constructor initializing the contrast and edge thresholds for keypoint detection.
        :param contrast_threshold: Contrast threshold for keypoint detection.
        :param edge_threshold: Edge threshold for keypoint detection (used in Hessian matrix).
        """
        self.contrast_threshold = contrast_threshold
        self.edge_threshold = edge_threshold
        pass

    def get_keypoints(self, blurred_image_pyramid):
        """
        Computes keypoints for each octave and scale.
        :param blurred_image_pyramid: List of octaves, each with a list of blurred images
        :return: List of keypoints as (x, y, octave, scale_index)
        """
        all_keypoints = []

        for octave_idx, blurred_images in enumerate(blurred_image_pyramid):
            dog_images = self.__get_dog_images(blurred_images)
            keypoints = self.__get_image_extrema(dog_images, octave_idx)
            all_keypoints.extend(keypoints)

        return all_keypoints

    def __get_dog_images(self, blurred_images):
        """"
        Computes the Difference of Gaussian (DoG) images from the blurred images.
        :param blurred_images: List of blurred images
        :return: List of DoG images
        """

        dog_images = []

        for i in range(0, len(blurred_images) - 1):
            dog_image = self.__get_image_difference(blurred_images[i + 1], blurred_images[i])
            dog_images.append(dog_image)

        return dog_images


    def __get_image_extrema(self, dog_images, octave_idx):
        """
        Detect extrema in DoG pyramid for a single octave.
        :param dog_images: List of DoG images for one octave
        :param octave_idx: Index of the octave in the pyramid
        :return: List of keypoints (x, y, octave, scale_index)
        """
        extrema_points = []

        for s in range(1, len(dog_images) - 1):
            prev = dog_images[s - 1]
            curr = dog_images[s]
            next = dog_images[s + 1]

            for y in range(1, curr.shape[0] - 1):
                for x in range(1, curr.shape[1] - 1):
                    patch = np.stack([
                        prev[y - 1:y + 2, x - 1:x + 2],
                        curr[y - 1:y + 2, x - 1:x + 2],
                        next[y - 1:y + 2, x - 1:x + 2]
                    ])
                    center = patch[1, 1, 1]

                    if not self.__check_extreme_point(center, patch):
                        continue

                    if not self.__check_high_contrast(center):
                        continue

                    if not self.__check_curve_shape(curr, x, y):
                        continue

                    extrema_points.append((x, y, octave_idx, s))

        return extrema_points

    def __check_extreme_point(self, value, patch):
        """
        Checks if the value is an extreme point (maximum or minimum) in the patch.
        :param value: Value to be checked
        :param patch: Patch of the image
        :return: Returns True if the value is an extreme point, False otherwise
        """
        return value == np.max(patch) or value == np.min(patch)

    def __check_high_contrast(self, value):
        """
        Checks if the value is above the contrast threshold.
        :param value: Value to be checked
        :return: Returns True if the value is above the contrast threshold, False otherwise
        """
        return abs(value) >= self.contrast_threshold

    def __check_curve_shape(self, curr, x, y):
        """
        Checks if the curve shape is suitable for keypoint detection.
        :param curr: Current image
        :param x: X coordinate of the point
        :param y: Y coordinate of the point
        :return: Returns True if the curve shape is suitable, False otherwise
        """
        Tr_H, Det_H = self.__get_hessian(curr, x, y)
        return Det_H > 0 and (Tr_H ** 2 / Det_H) < ((self.edge_threshold + 1) ** 2) / self.edge_threshold

    def __get_hessian(self, curr, x, y):
        """
        Computes the Hessian matrix for the given point in the image.
        :param curr: Current image
        :param x: X coordinate of the point
        :param y: Y coordinate of the point
        :return: Returns the trace and determinant of the Hessian matrix
        """
        Dxx = curr[y, x + 1] + curr[y, x - 1] - 2 * curr[y, x]
        Dyy = curr[y + 1, x] + curr[y - 1, x] - 2 * curr[y, x]
        Dxy = (curr[y + 1, x + 1] - curr[y + 1, x - 1] - curr[y - 1, x + 1] + curr[y - 1, x - 1]) / 4.0

        Tr_H = Dxx + Dyy
        Det_H = Dxx * Dyy - Dxy ** 2

        return Tr_H, Det_H


    def __get_image_difference(self, image1, image2):
        """
        Computes the difference between two images.
        :param image1: First image
        :param image2: Second image
        :return: Returns the difference image without normalization
        """
        if image1.shape != image2.shape:
            raise ValueError("Images must have the same shape.")

        image1 = image1.astype(np.float32)
        image2 = image2.astype(np.float32)

        diff = image1 - image2

        return diff