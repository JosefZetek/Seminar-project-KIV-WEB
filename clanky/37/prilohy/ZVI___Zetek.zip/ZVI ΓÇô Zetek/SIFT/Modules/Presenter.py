import matplotlib.pyplot as plt
import cv2
import numpy as np

class Presenter:

    @staticmethod
    def show_image_grayscale(image, title="Image"):
        """
        Displays an image using matplotlib.
        :param image: The image to be displayed.
        :param title: The title of the window.
        """
        plt.imshow(image, cmap='gray')
        plt.title(title)
        plt.axis('off')
        plt.show()

    @staticmethod
    def show_image_color(image, title="Image"):
        """
        Displays a color image using matplotlib.
        :param image: The image to be displayed.
        :param title: The title of the window.
        """
        plt.imshow(image)
        plt.axis('off')
        plt.gca().set_position([0, 0, 1, 1])
        plt.subplots_adjust(left=0, right=1, top=1, bottom=0)
        plt.show()

    @staticmethod
    def stitch_images(image1, image2, H):
        """
        Stitches two images together using a homography matrix.
        :param image1: First image
        :param image2: Second image
        :param H: Homography matrix
        :return: Returns the stitched image
        """
        # Get dimensions
        h1, w1 = image1.shape[:2]
        h2, w2 = image2.shape[:2]

        corners_img1 = np.float32([[0, 0], [0, h1], [w1, h1], [w1, 0]]).reshape(-1, 1, 2)
        transformed_corners_img1 = cv2.perspectiveTransform(corners_img1, H)

        # Combine corners with those of img2
        all_corners = np.concatenate(
            (transformed_corners_img1, np.float32([[0, 0], [0, h2], [w2, h2], [w2, 0]]).reshape(-1, 1, 2)), axis=0)

        [xmin, ymin] = np.int32(all_corners.min(axis=0).ravel() - 0.5)
        [xmax, ymax] = np.int32(all_corners.max(axis=0).ravel() + 0.5)

        # Translation to fit everything
        translation_dist = [-xmin, -ymin]
        H_translation = np.array([[1, 0, translation_dist[0]],
                                  [0, 1, translation_dist[1]],
                                  [0, 0, 1]])

        # Warp img1 into the panorama canvas
        result = cv2.warpPerspective(image1, H_translation @ H, (xmax - xmin, ymax - ymin))

        # Paste img2 onto result
        result[translation_dist[1]:h2 + translation_dist[1], translation_dist[0]:w2 + translation_dist[0]] = image2

        return cv2.cvtColor(result, cv2.COLOR_BGR2RGB)

    @staticmethod
    def draw_matches(image1, image2, src_points, dst_points, limit=10):
        """
        Draws lines between matched points in two images.
        :param image1: First image.
        :param image2: Second image.
        :param src_points: Points from the first image.
        :param dst_points: Points from the second image.
        :param limit: Percentage of matches to display.
        :return: Image with matches drawn.
        """
        # Create a new image to display the matches
        h1, w1 = image1.shape[:2]
        h2, w2 = image2.shape[:2]
        result = np.zeros((max(h1, h2), w1 + w2, 3), dtype=np.uint8)

        # Place the first image on the left
        result[:h1, :w1] = cv2.cvtColor(image1, cv2.COLOR_GRAY2RGB) if len(image1.shape) == 2 else cv2.cvtColor(image1, cv2.COLOR_BGR2RGB)

        # Place the second image on the right
        result[:h2, w1:w1 + w2] = cv2.cvtColor(image2, cv2.COLOR_GRAY2RGB) if len(image2.shape) == 2 else cv2.cvtColor(image2, cv2.COLOR_BGR2RGB)

        # Draw lines between matched points
        for p1, p2 in zip(src_points[:((len(src_points) - 1) * limit// 100)], dst_points[:((len(dst_points) - 1) * limit// 100)]):
            cv2.line(result, (int(p1[0]), int(p1[1])), (int(p2[0] + w1), int(p2[1])), (0, 255, 0), 1)

        return result