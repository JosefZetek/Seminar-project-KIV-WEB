import numpy as np

class TransformationCreator:

    @staticmethod
    def H_rotation_matrix(angle):
        """
        Create a 2D rotation matrix for a given angle in degrees.
        :param angle_rad: Angle in radians
        """
        angle_rad = np.deg2rad(angle)

        cos_angle = np.cos(angle_rad)
        sin_angle = np.sin(angle_rad)

        return np.array([[cos_angle, -sin_angle, 0],
                         [sin_angle, cos_angle, 0],
                         [0, 0, 1]])

    @staticmethod
    def H_translation_matrix(tx, ty):
        """
        Create a 2D translation matrix for given x and y translations.
        :param tx: Translation in x direction
        :param ty: Translation in y direction
        """
        return np.array([[1, 0, tx],
                         [0, 1, ty],
                         [0, 0, 1]])

    @staticmethod
    def get_rotation_matrix(H):
        """
        Extract the rotation matrix from a homography matrix.
        :param H: Homography matrix
        :return: Rotation matrix
        """
        return H[:2, :2]

    @staticmethod
    def get_translation_vector(H):
        """
        Extract the translation vector from a homography matrix.
        :param H: Homography matrix
        :return: Translation vector
        """
        return H[:2, 2]