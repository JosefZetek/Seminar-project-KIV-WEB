import numpy as np
import cv2
from DataStructures.Match import Match

class MatcherFLANN:

    def __init__(self):
        """
        Matcher using FLANN (Fast Library for Approximate Nearest Neighbors) for matching feature vectors.
        This matcher uses the KDTree algorithm for indexing and matching.
        """
        self.index_params = dict(algorithm=1, trees=5)  # algorithm=1 -> KDTree
        self.search_params = dict(checks=50)

    def match(self, feature_vectors1, feature_vectors2):
        """
        Match feature vectors using FLANN and Lowe's ratio test.
        :param feature_vectors1: Feature vectors from the first image.
        :param feature_vectors2: Feature vectors from the second image.
        :return: Returns a list of matches.
        """
        if not feature_vectors1 or not feature_vectors2:
            return []

        descriptors1 = np.array([fv.values for fv in feature_vectors1]).astype(np.float32)
        descriptors2 = np.array([fv.values for fv in feature_vectors2]).astype(np.float32)

        flann = cv2.FlannBasedMatcher(self.index_params, self.search_params)
        matches_cv = flann.knnMatch(descriptors1, descriptors2, k=2)

        matches = []
        for i, pair in enumerate(matches_cv):
            if len(pair) == 2:
                m, n = pair
                if m.distance < 0.75 * n.distance:
                    match = Match(feature_vectors1[m.queryIdx], feature_vectors2[m.trainIdx])
                    matches.append(match)
        return matches