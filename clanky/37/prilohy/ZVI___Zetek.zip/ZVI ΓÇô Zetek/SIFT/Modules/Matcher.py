from DataStructures.KMeansTree import KMeansTreeNode
from DataStructures.Match import Match

class Matcher:

    def __init__(self):
        pass

    def match(self, feature_vectors1, feature_vectors2):
        """
        Match feature vectors using KMeans tree and Lowe's ratio test.
        :param feature_vectors1: Feature vectors from the first image.
        :param feature_vectors2: Feature vectors from the second image.
        :return: Returns a list of matches.
        """
        matches = []
        root = KMeansTreeNode(feature_vectors1)

        for feature_vector2 in feature_vectors2:

            nearest_candidates = root.find_nearest_candidates(feature_vector2)

            if not nearest_candidates or len(nearest_candidates) == 0:
                continue

            if len(nearest_candidates) == 1:
                match = Match(nearest_candidates[0], feature_vector2)
                matches.append(match)
                continue

            closest, second_closest = nearest_candidates[0], nearest_candidates[1]

            if self.__lowe_ratio_test(feature_vector2, closest, second_closest):
                match = Match(closest, feature_vector2)
                matches.append(match)

        return matches

    def __lowe_ratio_test(self, reference, closest, second_closest):
        """
        Apply Lowe's ratio test to filter matches.
        :param matches: List of matches.
        :return: Filtered list of matches.
        """
        if closest.distance_to(reference) < 0.75 * second_closest.distance_to(reference):
            return True
        return False