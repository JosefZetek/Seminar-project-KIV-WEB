import cv2
import numpy as np

class Preprocesor:

    def __init__(self, number_of_scales=5, base_sigma=1.6):
        """
        Constructor initializing the number of scales for the DoG images.
        :param number_of_scales: Number of scales for the DoG images.
        """
        self.number_of_scales = number_of_scales
        self.base_sigma = base_sigma
        self.k = 2 ** (1 / self.number_of_scales)


    def resize_image(self, image, width, height):

        width_ratio = image.shape[1] / width
        height_ratio = image.shape[0] / height

        if len(image.shape) == 2:
            new_image = np.zeros((height, width), dtype=np.uint8)

            # Downsample grayscale image
            for i in range(height):
                for j in range(width):
                    new_image[i, j] = image[int(i * height_ratio), int(j * width_ratio)]

            return new_image

        if len(image.shape) == 3:
            new_image = np.zeros((height, width, 3), dtype=np.uint8)

            # Downsample RGB image
            for i in range(height):
                for j in range(width):
                    new_image[i, j] = image[int(i * height_ratio), int(j * width_ratio)]

            return new_image

        raise ValueError("Unsupported image format.")

    @staticmethod
    def resize_image2(image, width, height):

        width_ratio = image.shape[1] / width
        height_ratio = image.shape[0] / height

        if len(image.shape) == 2:
            new_image = np.zeros((height, width), dtype=np.uint8)

            # Downsample grayscale image
            for i in range(height):
                for j in range(width):
                    new_image[i, j] = image[int(i * height_ratio), int(j * width_ratio)]

            return new_image

        if len(image.shape) == 3:
            new_image = np.zeros((height, width, 3), dtype=np.uint8)

            # Downsample RGB image
            for i in range(height):
                for j in range(width):
                    new_image[i, j] = image[int(i * height_ratio), int(j * width_ratio)]

            return new_image

        raise ValueError("Unsupported image format.")


    def get_blurred_images(self, image, num_octaves=4):
        """
        Build scale-space: multiple octaves with progressively blurred images.
        :param image: input grayscale image
        :param num_octaves: number of octaves (each octave halves the resolution)
        :return: List of lists of blurred images per octave
        """
        octaves = []
        base_image = image.copy().astype(np.float32)

        for octave in range(num_octaves):
            gaussian_images = []
            sigmas = [self.base_sigma * (self.k ** i) for i in range(self.number_of_scales + 3)]  # +3 for DoG

            for sigma in sigmas:
                size = int(2 * np.ceil(3 * sigma) + 1)
                kernel = self.__get_gaussian_kernel(size, sigma)
                blurred = self.__convolve_2D(base_image, kernel)
                gaussian_images.append(blurred)

            octaves.append(gaussian_images)

            base_image = self.resize_image(base_image, base_image.shape[1] // 2, base_image.shape[0] // 2)

        return octaves

    def __get_gaussian_kernel(self, size, sigma):
        """
        Generate a Gaussian kernel.
        :param size: Size of the kernel (must be odd).
        :param sigma: Standard deviation of the Gaussian distribution.
        :return: Gaussian kernel as a 2D numpy array.
        """
        if size % 2 == 0:
            raise ValueError("Size must be an odd number.")

        kernel = np.zeros((size, size))
        center = size // 2

        for x in range(-center, center + 1):
            for y in range(-center, center + 1):
                kernel[x + center, y + center] = (1 / (2 * np.pi * sigma ** 2)) * np.exp(-(x ** 2 + y ** 2) / (2 * sigma ** 2))

        return kernel / np.sum(kernel)

    def __convolve_2D(self, image, kernel):
        """
        Perform 2D convolution on a grayscale image.
        :param image: 2D numpy array (grayscale image)
        :param kernel: 2D numpy array (kernel)
        :return: Convolved image (same shape as input)
        """
        if len(kernel.shape) != 2:
            raise ValueError("Kernel must be 2D.")
        if len(image.shape) != 2:
            raise ValueError("Image must be grayscale (2D).")

        kernel = np.flipud(np.fliplr(kernel))
        kh, kw = kernel.shape
        pad_h, pad_w = kh // 2, kw // 2

        # Pad image with reflection to handle borders
        padded = np.pad(image, ((pad_h, pad_h), (pad_w, pad_w)), mode='reflect')
        output = np.zeros_like(image)

        for i in range(image.shape[0]):
            for j in range(image.shape[1]):
                region = padded[i:i + kh, j:j + kw]
                output[i, j] = np.sum(region * kernel)

        return output

    @staticmethod
    def load_image_grayscale(image_path):
        """
        Load an image from a file.
        :param image_path: Path to the image file.
        :return: Loaded image as a numpy array.
        """
        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        if len(image.shape) != 2:
            raise ValueError("Image must be grayscale (2D).")
        return image

    @staticmethod
    def load_image_color(image_path):
        """
        Load an image from a file.
        :param image_path: Path to the image file.
        :return: Loaded image as a numpy array.
        """
        image = cv2.imread(image_path)
        if len(image.shape) != 3:
            raise ValueError("Image must be color (3D).")
        return image
