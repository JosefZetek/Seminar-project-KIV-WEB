import cv2
import numpy as np


class TransformationComputer:

    def compute_transformation_matches(self, matches):
        """
        Computes the transformation matrix based on matched points.
        :param matches: List of matched points.
        :return: Transformation matrix.
        """

        # Extract points from matches
        src_points, dst_points = self.get_points_array(matches)
        return self.compute_transformation_points(src_points, dst_points)

    def compute_transformation_points(self, src_points, dst_points):
        """
        Computes the transformation matrix based on matched points.
        :param matches: List of matched points.
        :return: Transformation matrix.
        """
        H, _ = cv2.findHomography(src_points, dst_points, cv2.RANSAC, 5.0)

        return H

    def get_points_array(self, matches):
        """
        Extracts source points from the feature vectors.
        :return: List of source points.
        """
        src_points = []
        dst_points = []

        # Extract points from matches
        for match in matches:
            point1 = match.feature_vector1.point
            point2 = match.feature_vector2.point

            src_points.append([point1.x, point1.y])
            dst_points.append([point2.x, point2.y])

        return np.array(src_points), np.array(dst_points)