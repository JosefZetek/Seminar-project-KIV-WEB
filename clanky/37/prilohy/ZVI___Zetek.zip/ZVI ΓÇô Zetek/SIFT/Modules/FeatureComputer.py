from DataStructures.FeatureVector import FeatureVector
from DataStructures.Point import Point
import numpy as np

from Modules.TransformationCreator import TransformationCreator


class FeatureComputer:

    def __init__(self, number_of_bins=8):
        """
        Initializes the FeatureComputer with the specified number of bins for the histogram.
        :param number_of_bins: Number of bins for the histogram.
        """
        self.window_size = 16
        self.required_space = self.window_size // 2
        self.quadrant_size = self.window_size // 4
        self.number_of_bins = number_of_bins
        self.max_degrees = 360


    def get_feature_vector(self, blurred_images, keypoints):
        """
        Computes the feature vectors for the given keypoints in the blurred images.
        :param blurred_images: List of blurred images
        :param keypoints:
        :return:
        """
        feature_vectors = []

        for (x, y, octave_idx,s) in keypoints:

            # Pro zapnutí možnosti registrace rotovaného obrázku odkomentovat
            # Odkomnetováním se zruší invariance vůči škálování
            # if octave_idx != 0:
            #     continue

            image = blurred_images[octave_idx][s]

            if self.__near_border(x, y, image.shape):
                continue

            # Initial patch (just for dominant orientation)
            init_patch = image[y - self.required_space:y + self.required_space + 1,
                         x - self.required_space:x + self.required_space + 1]

            orientations = self.__compute_dominant_orientations(init_patch)

            for angle in orientations:
                rotation_matrix, translation_vector = self.__get_transformation(angle, x, y)
                patch = self.__get_transformed_patch(image, x, y, rotation_matrix, translation_vector)

                dx = patch[:, 1:] - patch[:, :-1]
                dy = patch[1:, :] - patch[:-1, :]
                dx = dx[:-1, :]
                dy = dy[:, :-1]
                mag = np.sqrt(dx ** 2 + dy ** 2)
                ori = (np.rad2deg(np.arctan2(dy, dx)) % self.max_degrees)

                descriptor = []
                bin_width = self.max_degrees / self.number_of_bins

                for i in range(0, self.window_size, self.quadrant_size):
                    for j in range(0, self.window_size, self.quadrant_size):
                        hist = np.zeros(self.number_of_bins)
                        for u in range(self.quadrant_size):
                            for v in range(self.quadrant_size):
                                row = i + u
                                col = j + v

                                angle_local = ori[row, col]
                                magnitude = mag[row, col]

                                bin_float = angle_local / bin_width
                                low_bin = int(np.floor(bin_float)) % self.number_of_bins
                                high_bin = (low_bin + 1) % self.number_of_bins
                                weight_high = bin_float - np.floor(bin_float)
                                weight_low = 1 - weight_high

                                hist[low_bin] += magnitude * weight_low
                                hist[high_bin] += magnitude * weight_high
                        descriptor.extend(hist)

                descriptor = self.__normalize_descriptor(descriptor)
                descriptor = self.__clip_and_renormalize(descriptor)

                original_x = int(x * (2 ** octave_idx))
                original_y = int(y * (2 ** octave_idx))

                point = Point(original_x, original_y)
                feature_vector = FeatureVector(point, np.array(descriptor))
                feature_vectors.append(feature_vector)

        return feature_vectors

    def __get_transformed_patch(self, image, x, y, rotation_matrix, translation_vector):
        """
        Extracts a rotated patch centered at (x, y) using the transformation matrices.
        """
        half_size = self.required_space
        patch = np.zeros((2 * half_size + 1, 2 * half_size + 1))

        for i in range(-half_size, half_size + 1):
            for j in range(-half_size, half_size + 1):
                # Local coordinates relative to center
                local_coords = np.array([x + j, y + i])  # (col=x+j, row=y+i)

                transformed_coords = np.dot(rotation_matrix, local_coords) + translation_vector
                tx, ty = transformed_coords

                # Bilinear interpolation
                if (0 <= int(ty) < image.shape[0] - 1) and (0 <= int(tx) < image.shape[1] - 1):
                    patch[i + half_size, j + half_size] = self.__bilinear_interpolate(image, tx, ty)
                else:
                    patch[i + half_size, j + half_size] = 0  # Zero-padding for out-of-bounds
        return patch

    def __bilinear_interpolate(self, image, x, y):
        x0 = int(np.floor(x))
        x1 = x0 + 1
        y0 = int(np.floor(y))
        y1 = y0 + 1

        if x0 < 0 or y0 < 0 or x1 >= image.shape[1] or y1 >= image.shape[0]:
            return 0  # Out-of-bounds handling

        Ia = image[y0, x0]
        Ib = image[y0, x1]
        Ic = image[y1, x0]
        Id = image[y1, x1]

        wa = (x1 - x) * (y1 - y)
        wb = (x - x0) * (y1 - y)
        wc = (x1 - x) * (y - y0)
        wd = (x - x0) * (y - y0)

        return wa * Ia + wb * Ib + wc * Ic + wd * Id



    def __get_transformation(self, angle, x, y):
        """
        Computes the transformation matrices for the given angle and point (x, y).
        :param angle: The angle of rotation.
        :param x: The x-coordinate of the point.
        :param y: The y-coordinate of the point.
        :return: Returns the rotation matrix and translation vector.
        """

        H_translation = TransformationCreator.H_translation_matrix(-x, -y)
        H_rotation = TransformationCreator.H_rotation_matrix(-angle)
        H_translation_inv = TransformationCreator.H_translation_matrix(x, y)

        H = np.dot(H_translation_inv, np.dot(H_rotation, H_translation))
        return TransformationCreator.get_rotation_matrix(H), TransformationCreator.get_translation_vector(H)

    def __compute_dominant_orientations(self, patch, num_bins=36, threshold_ratio=0.8):
        """
        Compute dominant orientations in the patch using a histogram of orientations.
        :param patch: The image patch to analyze.
        :param num_bins: Number of bins for the histogram.
        :param threshold_ratio: Ratio to determine significant orientations.
        :return: Returns all orientations above threshold_ratio * max peak.
        """
        dx = patch[:, 1:] - patch[:, :-1]
        dy = patch[1:, :] - patch[:-1, :]

        dx = dx[:-1, :]
        dy = dy[:, :-1]
        mag = np.sqrt(dx ** 2 + dy ** 2)
        ori = (np.rad2deg(np.arctan2(dy, dx)) % self.max_degrees)

        hist = np.zeros(num_bins)
        bin_width = 360 / num_bins

        for m, o in zip(mag.flatten(), ori.flatten()):
            bin_idx = int(np.floor(o / bin_width)) % num_bins
            hist[bin_idx] += m

        max_val = np.max(hist)
        orientations = [(i * bin_width) for i, val in enumerate(hist) if val >= threshold_ratio * max_val]
        return orientations

    def __normalize_descriptor(self, descriptor):
        """
        Normalize the descriptor to unit length.
        """
        descriptor = np.array(descriptor)
        norm = np.linalg.norm(descriptor)
        if norm > 0:
            return descriptor / norm
        return descriptor

    def __clip_and_renormalize(self, descriptor):
        """
        Clip the descriptor values to a maximum of 0.2 and renormalize.
        """
        descriptor = np.clip(descriptor, 0, 0.2)
        norm = np.linalg.norm(descriptor)
        if norm > 0:
            return descriptor / norm
        return descriptor

    def __near_border(self, x, y, image_shape):
        """
        Check if the point (x, y) is too close to the border of the image.
        """
        height, width = image_shape
        return (x < self.required_space or y < self.required_space or
                x + self.required_space >= width or y + self.required_space >= height)
